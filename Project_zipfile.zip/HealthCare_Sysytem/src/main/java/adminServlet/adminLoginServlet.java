package adminServlet;



import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import databaseLogic.doctorDatabaseLogic;



//@WebServlet("/doctorServlet.doctorLoginServlet")
@WebServlet("/adminLogin")
public class adminLoginServlet extends HttpServlet {
    private doctorDatabaseLogic dbManager; // Create an instance of the DatabaseManager

    public void init() {
        // Initialize the DatabaseManager in the servlet's init method
        dbManager = new doctorDatabaseLogic();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		
    	HttpSession session = request.getSession();
        
    	String id = request.getParameter("id");
        String password = request.getParameter("password");

        // Perform user validation using the DatabaseManager
        

		if (password.equals("123") && id.equals("101")) {
			

//			session.setAttribute("adminObj", new User());
//			resp.sendRedirect("admin/index.jsp");
			 response.sendRedirect("adminHome.jsp");
		}
		else {
//			session.setAttribute("errorMsg", "Invalid Username or Password.");
			response.sendRedirect("adminLogin.jsp");
		}

    }

//    public void destroy() {
//        // Close the DatabaseManager's resources in the servlet's destroy method
//        if (dbManager != null) {
//            dbManager.closeConnection();
//        }
//    }
}

