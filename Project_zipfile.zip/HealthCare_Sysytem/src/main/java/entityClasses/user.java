package entityClasses;

public class user {
	private int id;
	private String name;
	private String phoneNo;
	private String password;
	private int age;
	
	
	public user() {
		super();
		// TODO Auto-generated constructor stub
	}


	public user(int id, String name, int age, String phoneNo, String password) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.phoneNo=phoneNo;
		this.password = password;
	}

	public user(String name, int age,String phoneNo, String password) {
		super();
		this.name = name;
		this.age = age;
		this.phoneNo=phoneNo;
		this.password = password;
	}


	public int getid() {
		return id;
	}


	public void setid(int id) {
		this.id = id;
	}


	public String getname() {
		return name;
	}


	public void setname(String name) {
		this.name = name;
	}

	public int getage() {
		return age;
	}


	public void setage(int age) {
		this.age = age;
	}


	public String getph() {
		return phoneNo;
	}


	public void setph(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


//	@Override
//	public String toString() {
//		return "User [id=" + id + ", fullName=" + name + ", email=" + email + ", password=" + password + "]";
//	}
	
	
	
	
	
	
	
	
}
