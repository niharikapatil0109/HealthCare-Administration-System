package entityClasses;

public class appt {

	private int aid;
	private int uid;
	private String fullName;
	private int age;
	private String phone;
	private int doctorId;
	private String appointmentDate;
	private String diseases;
	private String status;
	
	
	public appt() {
		super();
		// TODO Auto-generated constructor stub
	}


	public appt(int aid, int uid, String fullName,  int age, String phone, int doctorId, String appointmentDate, String diseases, String status) {
		super();
		this.aid = aid;
		this.uid = uid;
		this.fullName = fullName;
		this.age = age;
		this.phone = phone;
		this.doctorId = doctorId;
		this.appointmentDate = appointmentDate;
		this.diseases = diseases;
		this.status = status;
	}


	public appt(int uid, String fullName, int age, String appointmentDate, String email, String phone, String diseases, int doctorId, String address, String status) {
		super();
		this.uid = uid;
		this.fullName = fullName;
		this.age = age;
		this.appointmentDate = appointmentDate;
		this.phone = phone;
		this.diseases = diseases;
		this.doctorId = doctorId;
		this.status = status;
	}
	public int getaid() {
		return aid;
	}


	public void setaid(int aid) {
		this.aid = aid;
	}



	public int getId() {
		return uid;
	}


	public void setId(int uid) {
		this.uid = uid;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getAppointmentDate() {
		return appointmentDate;
	}


	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getDiseases() {
		return diseases;
	}


	public void setDiseases(String diseases) {
		this.diseases = diseases;
	}


	public int getDoctorId() {
		return doctorId;
	}


	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
	
}
