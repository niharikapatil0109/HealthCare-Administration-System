package databaseLogic;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.util.Date;
import java.util.List;

import entityClasses.appt;
import entityClasses.doctor;
import java.sql.Date;

public class apptDatabaseLogic {
    private Connection connection;
    private String jdbcURL = "jdbc:mysql://localhost:3306/HealthCare";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Ginni@123";

    public apptDatabaseLogic() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean addAppnt(int id, int userId, String name, int age, String phone, int doctorId, String date, String diseases, String status) {
        boolean isSuccess = false;

        try {
            String sql = "INSERT INTO appointment (aid, pid, pname, age,  phone, did, apptDate, disease, status) VALUES (?, ?, ?, ?, ?,?,?,?,?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.setInt(2, userId);
            pstmt.setString(3, name);
            pstmt.setInt(4, age);
            pstmt.setString(5, phone);
            pstmt.setInt(6, doctorId);
//            java.sql.Date sqlDate = java.sql.Date.valueOf(date);
//            pstmt.setDate(7, sqlDate);
//            pstmt.setDate(7, new java.sql.Date(date.getTime()));
            
            String hardcodedDate = "2023-11-13";
            pstmt.setDate(7, Date.valueOf(hardcodedDate));
          
            
      //      pstmt.setNull(7, java.sql.Types.DATE);

            pstmt.setString(8, diseases);
            pstmt.setString(9, status);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                isSuccess = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Provide additional information in the console log
            System.out.println("SQLException: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("VendorError: " + e.getErrorCode());
        }
        return isSuccess;
    }
//    public boolean addAppt(int id, int userId, String name, int age, String phone, int doctorId, Date date, String diseases, String status) {
//        boolean isSuccess = false;
//        
//        try {
//            String sql = "INSERT INTO appointment (aid, pid, pname, age, phone, did, apptDate, disease, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
//            PreparedStatement pstmt = connection.prepareStatement(sql);
//            pstmt.setInt(1, id);
//            pstmt.setInt(2, userId);
//            pstmt.setString(3, name);
//            pstmt.setInt(4, age);
//            pstmt.setString(5, phone);
//            pstmt.setInt(6, doctorId);
//            pstmt.setDate(7, new java.sql.Date(date.getTime()));
//            pstmt.setString(8, diseases);
//            pstmt.setString(9, status);
//
//            int rowsAffected = pstmt.executeUpdate();
//            if (rowsAffected > 0) {
//                isSuccess = true;
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            // Provide additional information in the console log
//            System.out.println("SQLException: " + e.getMessage());
//            System.out.println("SQLState: " + e.getSQLState());
//            System.out.println("VendorError: " + e.getErrorCode());
//        }
//        return isSuccess;
//    }
//
    public List<appt> viewapptbyid(int uid) {
    	
    	appt a = null;
    	List<appt> patappt = new ArrayList<>();
    	try {
            String query = "SELECT * FROM appointment where pid=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, uid); 
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                a = new appt();
                a.setaid(resultSet.getInt(1));
                a.setId(resultSet.getInt(2));
                a.setFullName(resultSet.getString(3));
                a.setAge(resultSet.getInt(4)); // Assuming the age is an integer in the database
                a.setPhone(resultSet.getString(5));
                a.setDoctorId(resultSet.getInt(6));
                a.setAppointmentDate(resultSet.getString(7)); // Assuming appointment date is stored as string in the database
                a.setDiseases(resultSet.getString(8));
                a.setStatus(resultSet.getString(9));
                patappt.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as required (logging, specific error messages, etc.)
        }

        return patappt; // Return 'a' outside the try-catch block
    }
    
 
    
    
    public List<appt> viewapptbydocid(int did) {

    	appt a = null;
    	List<appt> docappt = new ArrayList<>();
    	try {
            String query = "SELECT * FROM appointment where did=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, did); 
            ResultSet resultSet = statement.executeQuery();
            
            while (resultSet.next()) {
                a = new appt();
                a.setaid(resultSet.getInt(1));
                a.setId(resultSet.getInt(2));
                a.setFullName(resultSet.getString(3));
                a.setAge(resultSet.getInt(4)); 
                a.setPhone(resultSet.getString(5));
                a.setDoctorId(resultSet.getInt(6));
                a.setAppointmentDate(resultSet.getString(7)); 
                a.setDiseases(resultSet.getString(8));
                a.setStatus(resultSet.getString(9));
                
                docappt.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as required (logging, specific error messages, etc.)
        }

        return docappt; 
    }
    
 
    
    
    public boolean updateStat(int aid) {
        boolean isSuccess = false;

        try {
            String sql = "UPDATE appointment SET status='check' WHERE aid=?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, aid); // Set the value for the parameter

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                isSuccess = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Consider handling the exception more robustly (logging, specific error messages, etc.)
        }

        return isSuccess;
    }

    public List<appt> displayAllAppts() throws SQLException {
    	appt a = null;
        List<appt> appnt = new ArrayList<>();
        
    	try {
        String query = "SELECT * FROM appointment"; 
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {
            a = new appt();
            a.setaid(resultSet.getInt(1));
            a.setId(resultSet.getInt(2));
            a.setFullName(resultSet.getString(3));
            a.setAge(resultSet.getInt(4)); 
            a.setPhone(resultSet.getString(5));
            a.setDoctorId(resultSet.getInt(6));
            a.setAppointmentDate(resultSet.getString(7)); 
            a.setDiseases(resultSet.getString(8));
            a.setStatus(resultSet.getString(9));
            
            appnt.add(a);
        }
    	}
    	 catch (SQLException e) {
    	        e.printStackTrace();
    	    }
 
    	
        return appnt;
    }
    
    
}



