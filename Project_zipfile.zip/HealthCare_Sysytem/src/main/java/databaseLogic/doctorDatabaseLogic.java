package databaseLogic;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entityClasses.doctor;

public class doctorDatabaseLogic {
    private Connection connection;
    private String jdbcURL = "jdbc:mysql://localhost:3306/HealthCare";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Ginni@123";

    public doctorDatabaseLogic() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public doctor validateUser(int id, String pwd) {
    	doctor d=null;
        String sql = "SELECT * FROM doctor WHERE id = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.setString(2, pwd);

            ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {
				d = new doctor();

				d.setid(resultSet.getInt(1));
				d.setname(resultSet.getString(2));
				d.setQualification(resultSet.getString(3));
				d.setPhone(resultSet.getString(4));
				
				return d;

			}
        } catch (SQLException e) {
            e.printStackTrace();
           
        }
		return d;
    }
    
    public List<doctor> displayAllDocs() throws SQLException {
    	
        String query = "SELECT * FROM doctor"; 
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();

        List<doctor> doctors = new ArrayList<>();

        while (resultSet.next()) {
            doctor d = new doctor();
            d.setid(resultSet.getInt(1));
            d.setname(resultSet.getString(2));
            d.setQualification(resultSet.getString(3));
            d.setPhone(resultSet.getString(4));

            doctors.add(d);
        }

        return doctors;
    }
    
    
	// delete doctors by id
	public boolean deleteDoctorById(int id) {

		boolean f = false;

		try {

			String sql = "delete from doctor where id=?";
			PreparedStatement pstmt = this.connection.prepareStatement(sql);
			pstmt.setInt(1, id);

			pstmt.executeUpdate();

			f = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return f;
	}

    
    
}



