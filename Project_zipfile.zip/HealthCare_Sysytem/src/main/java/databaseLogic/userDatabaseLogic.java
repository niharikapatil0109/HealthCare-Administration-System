package databaseLogic;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entityClasses.doctor;
import entityClasses.user;



public class userDatabaseLogic  {

	private Connection conn;
    private String jdbcURL = "jdbc:mysql://localhost:3306/HealthCare";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Ginni@123";

    public userDatabaseLogic() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean userRegister(int id, String name, int age, String phoneNo, String password) {
        boolean isSuccess = false;

        try {
            String sql = "INSERT INTO patients (id, name, age, phoneNo, password) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setInt(3, age);
            pstmt.setString(4, phoneNo);
            pstmt.setString(5, password);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                isSuccess = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Consider handling the exception more robustly (logging, specific error messages, etc.)
        }

        return isSuccess;
    }
    
    
    public user validateUser(String phoneNo, String pwd) {
    	user u=null;
        String sql = "SELECT * FROM patients WHERE phoneNo = ? AND password = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, phoneNo);
            statement.setString(2, pwd);

            ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {
				u= new user();

				u.setid(resultSet.getInt(1));
				u.setname(resultSet.getString(2));
				u.setage(resultSet.getInt(3));
				u.setph(resultSet.getString(4));
				
				return u;

			}
        } catch (SQLException e) {
            e.printStackTrace();
           
        }
		return u;
    }
   
}



