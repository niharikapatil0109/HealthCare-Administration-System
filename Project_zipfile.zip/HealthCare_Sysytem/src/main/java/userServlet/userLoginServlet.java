package userServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

import databaseLogic.doctorDatabaseLogic;
import databaseLogic.userDatabaseLogic;
import entityClasses.doctor;
import entityClasses.user;



//@WebServlet("/doctorServlet.doctorLoginServlet")
@WebServlet("/userLogin")
public class userLoginServlet extends HttpServlet {
  private userDatabaseLogic db; // Create an instance of the DatabaseManager

  public void init() {
      // Initialize the DatabaseManager in the servlet's init method
      db = new userDatabaseLogic();
  }

  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
  	
		HttpSession session = request.getSession();
      
      String ph = request.getParameter("phone");
      String password = request.getParameter("password");


      user u= null;
      u = db.validateUser(ph, password);

      if (u!=null) {
          // Redirect to a JSP page displaying user details
			session.setAttribute("userObj", u);
      	    response.sendRedirect("userHome.jsp");
      } else {
    	    request.setAttribute("errorMessage", "Invalid credentials. Please try again.");
    	    request.getRequestDispatcher("userLogin.jsp").forward(request, response);
    	}
  }

}