package userServlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import databaseLogic.apptDatabaseLogic;
import databaseLogic.userDatabaseLogic;
import entityClasses.appt;
import entityClasses.user;


@WebServlet("/addUserAppt")
public class addAppt extends HttpServlet {
  private apptDatabaseLogic db; // Create an instance of the DatabaseManager

  int count=63;
  public void init() {
      // Initialize the DatabaseManager in the servlet's init method
      db = new apptDatabaseLogic();
  }

  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
  	
	    PrintWriter out = response.getWriter();
	    HttpSession session = request.getSession();

	    // Check if the session contains the "userObj" attribute
	    if (session.getAttribute("userObj") == null) {
	        // Redirect or display an error message
	        request.setAttribute("errorMessage", "Session expired. Please login again.");
	        request.getRequestDispatcher("userLogin.jsp").forward(request, response);
	        return;
	    }

	  String dis=request.getParameter("diseaseInfo");
	  
//	  String dt = request.getParameter("appointmentDate");
//	  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//	  Date date = null;
//	  try {
//	      date = dateFormat.parse(dt);
//	  } catch (ParseException e) {
//	      e.printStackTrace();
//	  }

	  
	  
	  
	  
//	  String dt = request.getParameter("appointmentDate");
//
//      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//      Date utilDate = null;
//      try {
//          utilDate = dateFormat.parse(dt);
//      } catch (ParseException e) {
//          e.printStackTrace();
//      }
//
//      // Convert utilDate to sqlDate for database insertion
//      Date sqlDate = new Date(utilDate.getTime());
//      
		String appointmentDate = request.getParameter("appointmentDate");
	  
	  
	  
//      String dt = request.getParameter("appointmentDate");
//
//      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//      Date utilDate = null;
//
//      try {
//          utilDate = dateFormat.parse(dt);
//      } catch (ParseException e) {
//          e.printStackTrace();
//      }

	  String d =request.getParameter("doctor");
	  int Did=Integer.parseInt(d);
	  
	  
	  user currentuser = (user)session.getAttribute("userObj");
	  
	  int aid=++count;
      boolean a= false;
      a = db.addAppnt(aid, currentuser.getid(), currentuser.getname(),currentuser.getage(),currentuser.getph(), Did ,appointmentDate ,dis, "uncheck");

//      if (a) {
//    	  response.setContentType("text/html");
//			out.print("<h3 style='color:green'> Registration Successful </h3>");
//			RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");
//			rd.include(request,response);
//      	    response.sendRedirect("userHome.jsp");
//      } else {
//          
//      }
      
      
      if (a) {
    	    response.setContentType("text/html");
    	    out.print("<script>alert('Appointment added successfully');</script>");
    	    RequestDispatcher rd = request.getRequestDispatcher("userHome.jsp");
    	    rd.include(request, response);
    	    response.sendRedirect("userHome.jsp");
    	} else {
//    	    response.setContentType("text/html");
//    	    out.print("<script>alert('Appointment not added');</script>");
    	    request.setAttribute("errorMessage", "Appointment not booked. try again");
    	    request.getRequestDispatcher("userBookAppt.jsp").forward(request, response);
    	}

  }
  
}
