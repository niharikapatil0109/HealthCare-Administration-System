package userServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import databaseLogic.userDatabaseLogic;



//@WebServlet("/doctorServlet.doctorLoginServlet")
@WebServlet("/userReg")
public class userRegServlet extends HttpServlet {
    private userDatabaseLogic db;
    int count=55;

    public void init() {
        // Initialize the DatabaseManager in the servlet's init method
        db = new userDatabaseLogic();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
		HttpSession session = request.getSession();

        String name = request.getParameter("name");
        String a = request.getParameter("age");
        int age=Integer.parseInt(a);
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");

        count++;
        boolean t=db.userRegister(count,name,age,phone,password);
        if (t) {
        	session.setAttribute("registrationSuccess", "Registration Successful!");
        	response.sendRedirect("userRegSuccess.jsp");
        } else {
            // Redirect back to the login page with an error message
//        	response.sendRedirect("userReg.jsp");
    	    request.setAttribute("errorMessage", "User not registered. Try again");
    	    request.getRequestDispatcher("userReg.jsp").forward(request, response);
            
        }
    }
    
}
