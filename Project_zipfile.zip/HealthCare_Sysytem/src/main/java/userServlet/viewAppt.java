//package userServlet;
//
//import jakarta.servlet.RequestDispatcher;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.annotation.WebServlet;
//import jakarta.servlet.http.HttpServlet;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpSession;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//import databaseLogic.apptDatabaseLogic;
//import databaseLogic.userDatabaseLogic;
//import entityClasses.appt;
//import entityClasses.user;
//
//
//@WebServlet("/viewUserAppt")
//public class viewAppt extends HttpServlet {
//  private apptDatabaseLogic db; // Create an instance of the DatabaseManager
//
//  int count=0;
//  public void init() {
//      // Initialize the DatabaseManager in the servlet's init method
//      db = new apptDatabaseLogic();
//  }
//
//  protected void doPost(HttpServletRequest request, HttpServletResponse response)
//          throws ServletException, IOException {
//  	
//	  PrintWriter out=response.getWriter();
//	 HttpSession session = request.getSession();
// 
//
//	  
//	  user currentuser = (user)session.getAttribute("userObj");
//
//      appt a;
//      a = db.viewapptbyid(currentuser.getid());
//
//      if (a!=null) {
//			session.setAttribute("apptObj", a);
//      	    response.sendRedirect("userApptDetails.jsp");
//      	    
//      } else {
//          // Redirect back to the login page with an error message
//          
//      }
//  }
//  
//}
