package doctorServlet;



import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import databaseLogic.doctorDatabaseLogic;
import entityClasses.doctor;



//@WebServlet("/doctorServlet.doctorLoginServlet")
@WebServlet("/doctorLogin")
public class doctorLoginServlet extends HttpServlet {
    private doctorDatabaseLogic dbManager; // Create an instance of the DatabaseManager

    public void init() {
        // Initialize the DatabaseManager in the servlet's init method
        dbManager = new doctorDatabaseLogic();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
		HttpSession session = request.getSession();
        // Retrieve user input
        String id = request.getParameter("id");
        int docid=Integer.parseInt(id);
        String password = request.getParameter("password");


        // Perform user validation using the DatabaseManager
        doctor d = dbManager.validateUser(docid, password);

        if (d!=null) {
            // Redirect to a JSP page displaying user details
			session.setAttribute("doctorObj", d);
        	response.sendRedirect("doctorHome.jsp");
        } else {
            // Redirect back to the login page with an error message
            
        }
    }

//    public void destroy() {
//        // Close the DatabaseManager's resources in the servlet's destroy method
//        if (dbManager != null) {
//            dbManager.closeConnection();
//        }
//    }
}

