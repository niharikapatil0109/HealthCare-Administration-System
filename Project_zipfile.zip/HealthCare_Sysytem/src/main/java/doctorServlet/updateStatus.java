package doctorServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import databaseLogic.apptDatabaseLogic;
import databaseLogic.doctorDatabaseLogic;
import entityClasses.doctor;


@WebServlet("/updateApptStatus")
public class updateStatus extends HttpServlet {
    private apptDatabaseLogic db; // Create an instance of the DatabaseManager

    public void init() {
        // Initialize the DatabaseManager in the servlet's init method
        db = new apptDatabaseLogic();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
		HttpSession session = request.getSession();
        // Retrieve user input
        String id = request.getParameter("buttonId");
        int apid=Integer.parseInt(id);

        boolean flag = db.updateStat(apid);

        if (flag) {
        	response.sendRedirect("doctorApptDetails.jsp");
        } else {
            // Redirect back to the login page with an error message
            
        }
    }
};